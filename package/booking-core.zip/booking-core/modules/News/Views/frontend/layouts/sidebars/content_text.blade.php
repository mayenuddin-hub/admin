<div class="sidebar-widget">
    <div class="sidebar-title">
        <h4>{{ $item->title }}</h4>
    </div>
    <div class="textwidget">
        {{ $item->content }}
    </div>
</div>