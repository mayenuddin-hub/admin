<?php
/**
 * Created by PhpStorm.
 * User: h2 gaming
 * Date: 7/3/2019
 * Time: 9:32 PM
 */
return [
    'news_route_prefix' => env("NEWS_ROUTER_PREFIX","news"),
    'news_category_route_prefix' => env("NEWS_CATEGORY_ROUTER_PREFIX","category"),
    'news_tag_route_prefix' => env("NEWS_TAG_ROUTER_PREFIX","tag"),
];